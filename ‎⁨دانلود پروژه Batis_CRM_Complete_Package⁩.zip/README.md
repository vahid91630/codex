# Batis CRM Bot
این پروژه شامل ربات تلگرامی هوشمند برای CRM، حسابداری، انبارداری و مشاوره فروش است.
- برای اجرا: `python main.py`
- تنظیمات در فایل `.env`
- اتصال به SQL Server، OpenAI و Google Drive پیکربندی شده است.